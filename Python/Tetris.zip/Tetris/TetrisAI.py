import time
def runByAI():
    if pause == True:
        return 0
    
