function R1 = rotate_y(b,R0)
Ry = [cos(b) 0 sin(b);0 1 0;-sin(b) 0 cos(b)];
R1 = R0 * Ry;
solar_plane(R1);
end