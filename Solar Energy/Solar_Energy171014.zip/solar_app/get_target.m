function R_target = get_target(elevation_deg,azimuth_deg)
elevation_rad = deg2rad(elevation_deg);
azimuth_rad = deg2rad(azimuth_deg);
a = azimuth_rad;
b = pi/2 - elevation_rad;
Rz = [cos(a) -sin(a) 0;sin(a) cos(a) 0;0 0 1];
Ry = [cos(b) 0 sin(b);0 1 0;-sin(b) 0 cos(b)];
R_target = Rz*Ry;
end