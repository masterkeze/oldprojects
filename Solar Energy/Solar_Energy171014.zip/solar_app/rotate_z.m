function R1 = rotate_z(a,R0)
Rz = [cos(a) -sin(a) 0;sin(a) cos(a) 0;0 0 1];
R1 = Rz * R0;
solar_plane(R1);
end