
function solar_plane(R0)
w = 5;
corners = [w w -w -w;w -w -w w;0 0 0 0];
corners = R0 * corners;
X = corners(1,:);
Y = corners(2,:);
Z = corners(3,:);
fill3(X,Y,Z,abs(Z+w)/10);
xlim([-10 10]);
ylim([-10 10]);
zlim([-10 10]);
xlabel('X');
ylabel('Y');
zlabel('Z');
hold on
boat = [-w -w 1.5*w;-w w 0;-8 -8 -8];
x = boat(1,:);
y = boat(2,:);
z = boat(3,:);
fill3(x,y,z,'g');
hold off
end

