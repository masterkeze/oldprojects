function [latitude,longitude,time_zone,y,mo,d,h,mi,s] = data_feeder()
latitude = 22;
longitude = 114;
time_zone = 8;
format shortg
c = clock;
fix(c);
y = c(0);
mo = c(1);
d = c(2);
h = c(3);
mi = c(4);
s = c(5);

end