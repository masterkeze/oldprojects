
function test(x)
set(10,10);
draw()



function set(l1,l2)
global d1 d2;
d1 = l1;
d2 = l2;

function draw()



