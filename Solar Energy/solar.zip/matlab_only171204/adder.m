function c = adder(a,b)
c = a +2* b;
end