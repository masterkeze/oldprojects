function seconds = get_second(c)
seconds = c(4)*3600 + c(5)*60 + c(6);
end